<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run()
    {
        // membuat data
        $data = [
            [
                'nama' => 'Skintific',
                'harga'  => 10899000,
                'jumlah' => 5,
                'foto' => 'skintific.jpg',
                'kategori_id' => 6, // ID kategori Sofas
                'deskripsi' => 'Skincare Untuk menjaga skin barier',
                'created_at' => date("Y-m-d H:i:s"),
            ],
            [
                'nama' => 'Glad2glow',
                'harga'  => 150000,
                'jumlah' => 7,
                'foto' => 'glad2glow.jpg',
                'kategori_id' => 7, // ID kategori Sofas
                'deskripsi' => 'Skincare untuk mencerahkan',
                'created_at' => date("Y-m-d H:i:s"),
            ],
            [
                'nama' => 'Whitelab',
                'harga'  => 250000,
                'jumlah' => 5,
                'foto' => 'whitelab.jpg',
                'kategori_id' => 4, // ID kategori Sofas
                'deskripsi' => 'Skincare Untuk kulit berjerawat',
                'created_at' => date("Y-m-d H:i:s"),
            ],
            [
                'nama' => 'Emina',
                'harga'  => 300000,
                'jumlah' => 7,
                'foto' => 'emina.jpg',
                'kategori_id' => 3, // ID kategori Sofas
                'deskripsi' => 'Skincare Untuk menjaga mencerahkan',
                'created_at' => date("Y-m-d H:i:s"),
            ],
            [
                'nama' => 'Hanasui',
                'harga'  => 150000,
                'jumlah' => 7,
                'foto' => 'hanasui.jpg',
                'kategori_id' => 5, // ID kategori Sofas
                'deskripsi' => 'Skincare Untuk menjaga skin barier',
                'created_at' => date("Y-m-d H:i:s"),
            ],
            [
                'nama' => 'Wardah',
                'harga'  => 200000,
                'jumlah' => 7,
                'foto' => 'wardah.jpg',
                'kategori_id' => 2, // ID kategori Sofas
                'deskripsi' => 'Skincare Untuk menjaga skin barier',
                'created_at' => date("Y-m-d H:i:s"),
            ]
        ];

        foreach ($data as $item) {
            // insert semua data ke tabel
            $this->db->table('products')->insert($item);
        }
    }
}