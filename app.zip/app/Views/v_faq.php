<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
ini halaman faq
<?= $this->endSection() ?>